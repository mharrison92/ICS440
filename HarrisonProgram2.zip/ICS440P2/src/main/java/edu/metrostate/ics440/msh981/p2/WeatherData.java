package edu.metrostate.ics440.msh981.p2;

public class WeatherData {
	String id;
	int year;
	int month;
	int day;
	String element;
	double value;
	String qflag;

}
