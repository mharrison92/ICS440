package edu.metrostate.ics440.msh981.p2;

public class StationData {
	@Override
	public String toString() {
		return String.format("StationData [latitude=%s, longitude=%s, elevation=%s, state=%s, name=%s]", latitude,
				longitude, elevation, state, name);
	}
	String id;
	float latitude;
	float longitude;
	float elevation;;
	String state;
	String name;
}
