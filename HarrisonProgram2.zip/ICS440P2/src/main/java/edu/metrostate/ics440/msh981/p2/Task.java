package edu.metrostate.ics440.msh981.p2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Iterator;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Task implements Callable {

	public ConcurrentLinkedQueue<WeatherData> minMaxOfFile = new ConcurrentLinkedQueue<WeatherData>();
	public static ConcurrentLinkedQueue<StationData> stations = new ConcurrentLinkedQueue<StationData>();
	int minMax;
	File file;

	public Task(File file, int minMax) {
		this.file = file;
		this.minMax = minMax;
	}

	

	public Task call() throws Exception {
	
		Scanner scanner = new Scanner(file);

		String readLine = "";

		int j = 0;

		while (scanner.hasNextLine() && !(j == 10)) {
			readLine = scanner.nextLine();
			j++;
			if (j >= 3) {
				processLine(readLine);
			}
		}

		return this;
	}
	

	public ConcurrentLinkedQueue<WeatherData> getMinMaxOfFile() {
		return minMaxOfFile;
	}
	
	public ConcurrentLinkedQueue<StationData> getStaionData() {
		return stations;
	}

	public void processLine(String thisLine) {
		
		String str = "AF000040930  35.3170   69.0170 3366.0    NORTH-SALANG                   GSN     40930";
		if (thisLine.length() <= str.length()) {
			StationData sd = new StationData(); 
			sd.id = thisLine.substring(0,11);
			sd.latitude = Float.valueOf(thisLine.substring(12,20).trim()); 
			sd.longitude = Float.valueOf(thisLine.substring(21,30).trim());
			sd.elevation = Float.valueOf(thisLine.substring(31,37).trim());
			sd.state = thisLine.substring(38,40);
			sd.name = thisLine.substring(41,71);
			stations.add(sd);
		}
		else {
		String id = thisLine.substring(0, 11);
		int year = Integer.valueOf(thisLine.substring(11, 15).trim());
		int month = Integer.valueOf(thisLine.substring(15, 17).trim());
		String element = thisLine.substring(17, 21);
		int days = (thisLine.length() - 21) / 8; // Calculate the number of days in the line

			for (int i = 0; i < days; i++) { // Process each day in the line.
				WeatherData wd = new WeatherData();
				wd.day = i + 1;
				int value = Integer.valueOf(thisLine.substring(21+8*i,26+8*i).trim());
				   String qflag = thisLine.substring(27+8*i,28+8*i);
				   wd.id = id;
				   wd.year = year;
				   wd.month = month;
				   wd.element = element;
				   wd.value = value;
				   wd.qflag = qflag;
				// adding weatherData in the Concurrent queue
				minMaxOfFile.add(wd);

			}
		}
	}



	public static String areSameId(WeatherData w) {
		Iterator<StationData> it = stations.iterator();
		while(it.hasNext()) {
			String str = it.next().id;
			if (str.contains(w.id)) {
				System.out.println(it.toString());
			}
		}
		return it.toString();
		
	}
}
